﻿using JobOverview.POCO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JobOverview.DAL
{
    public class DALTache
    {
        //Récupérer la liste des activités d'un métier
        public static List<Activite> GetActivite(string codeMetier)
        {
            var listActivite = new List<Activite>();

            var connectString = ListeDonnees.Connexion.Chaine;
            string queryString = @"select distinct A.CodeActivite,A.Libelle
                from jo.Metier M
                inner join jo.ActiviteMetier AC on AC.MetierCodeMetier = M.CodeMetier
                inner join jo.Activite A on A.CodeActivite = AC.ActiviteCodeActivite
                where M.CodeMetier =@Code and A.Annexe = 0";

            var code = new SqlParameter("@Code", DbType.String);
            code.Value = codeMetier;

            using (var connect = new SqlConnection(connectString))
            {
                var command = new SqlCommand(queryString, connect);
                command.Parameters.Add(code);
                connect.Open();

                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        GetActiviteFromDataReader(listActivite, reader);
                    }
                }
            }

            return listActivite;
        }

        //Création des instances d'activité lues en BDD
        private static void GetActiviteFromDataReader(List<Activite> lstLog, SqlDataReader reader)
        {
            Activite act = new Activite();

            act.CodeActivite = (string)reader["CodeActivite"];
            act.Libelle = (string)reader["Libelle"];

            lstLog.Add(act);
        }

        //Insertion de la liste des taches de production en base avec requête de de masse
        //Cette méthode ajoute d'abord les tâches dans la table tache avant de les ajouter dans la table tacheprod
        public static void AjoutMasseTacheProdBD(List<TacheProd> listTacheProd)
        {
            var connectString = ListeDonnees.Connexion.Chaine;
            string queryStringTache = @"insert jo.Tache(IdTache, Libelle,Annexe,CodeActivite,Login, Description)
                select Id,Libelle,Annexe,Activite,Login,Description from @table";
            string queryStringTacheProd = @"insert jo.TacheProd(IdTache,DureePrevue,DureeRestanteEstimee,CodeModule,
                CodeLogicieModule,NumeroVersion,CodeLogicielVersion)
                select Id,DureePrevue,DureeRestante,Module,LogicielModule,NumeroVersion,Logicielversion 
                from @tableprod";
            string queryStringTravail = @"insert jo.Travail(IdTache,DateTravail,Heures,TauxProductivite)
                select Id,DateTravail,Heures,TauxProductivite from @tableTravail";

            //Création des paramètres de type tables mémoire
            var tache = new SqlParameter("@table", SqlDbType.Structured);
            var tacheProd = new SqlParameter("@tableprod", SqlDbType.Structured);
            var travail = new SqlParameter("@tableTravail", SqlDbType.Structured);

            DataTable tableTache, tableTacheProd, tableTravail;
            GetDataTabletacheProd(listTacheProd, out tableTache, out tableTacheProd, out tableTravail);

            tache.TypeName = "TypeTableTache";
            tache.Value = tableTache;

            tacheProd.TypeName = "TypeTableTacheprod";
            tacheProd.Value = tableTacheProd;

            travail.TypeName = "TypeTableTravail";
            travail.Value = tableTravail;

            using (var connect = new SqlConnection(connectString))
            {
                connect.Open();
                SqlTransaction tran = connect.BeginTransaction();

                //Création des commandes et affectation des paramètres
                var commandTache = new SqlCommand(queryStringTache, connect, tran);
                commandTache.Parameters.Add(tache);

                var commandTacheProd = new SqlCommand(queryStringTacheProd, connect, tran);
                commandTacheProd.Parameters.Add(tacheProd);

                var commandTravail = new SqlCommand(queryStringTravail, connect, tran);
                commandTravail.Parameters.Add(travail);

                try
                {
                    commandTache.ExecuteNonQuery();
                    commandTacheProd.ExecuteNonQuery();
                    commandTravail.ExecuteNonQuery();
                    tran.Commit();
                }
                catch (Exception)
                {
                    tran.Rollback();
                    throw;
                }
            }
        }

        //Création et remplissage de deux tables mémoire à partir d'une liste de tache de production
        private static void GetDataTabletacheProd(List<TacheProd> listTacheProd, out DataTable tableTache,
            out DataTable tableTacheProd, out DataTable tableTravail)
        {
            //Création des tables mémoire
            tableTache = new DataTable();
            tableTacheProd = new DataTable();
            tableTravail = new DataTable();


            //Création des colonnes et ajout à la table Tache
            #region Colonnes tableTache
            var colId = new DataColumn("Id", typeof(Guid));
            colId.AllowDBNull = false;
            tableTache.Columns.Add(colId);

            var colLibelle = new DataColumn("Libelle", typeof(string));
            colLibelle.AllowDBNull = false;
            tableTache.Columns.Add(colLibelle);

            var colAnnexe = new DataColumn("Annexe", typeof(bool));
            colAnnexe.AllowDBNull = false;
            tableTache.Columns.Add(colAnnexe);

            var colActivite = new DataColumn("Activite", typeof(string));
            colActivite.AllowDBNull = false;
            tableTache.Columns.Add(colActivite);

            var colLogin = new DataColumn("Login", typeof(string));
            colLogin.AllowDBNull = false;
            tableTache.Columns.Add(colLogin);

            var colDescription = new DataColumn("Description", typeof(string));
            tableTache.Columns.Add(colDescription);
            #endregion

            //Création des colonnes et ajout à la table travail
            #region Colonnes tableTache
            var colTravId = new DataColumn("Id", typeof(Guid));
            colTravId.AllowDBNull = false;
            tableTravail.Columns.Add(colTravId);

            var colTravDateTravail = new DataColumn("DateTravail", typeof(DateTime));
            colTravDateTravail.AllowDBNull = false;
            tableTravail.Columns.Add(colTravDateTravail);

            var colTravHeures = new DataColumn("Heures", typeof(float));
            colTravHeures.AllowDBNull = false;
            tableTravail.Columns.Add(colTravHeures);

            var colTravTauxProductivite = new DataColumn("TauxProductivite", typeof(float));
            colTravTauxProductivite.AllowDBNull = false;
            tableTravail.Columns.Add(colTravTauxProductivite);
            #endregion

            //Création des colonnes et ajout à la table Tacheprod
            #region Colonnes tableTacheProd
            var columnId = new DataColumn("Id", typeof(Guid));
            colId.AllowDBNull = false;
            tableTacheProd.Columns.Add(columnId);

            var columnDureePrevue = new DataColumn("DureePrevue", typeof(float));
            columnDureePrevue.AllowDBNull = false;
            tableTacheProd.Columns.Add(columnDureePrevue);

            var columnDureeRestante = new DataColumn("DureeRestante", typeof(float));
            columnDureeRestante.AllowDBNull = false;
            tableTacheProd.Columns.Add(columnDureeRestante);

            var columnModule = new DataColumn("Module", typeof(string));
            columnModule.AllowDBNull = false;
            tableTacheProd.Columns.Add(columnModule);

            var columnLogicielModule = new DataColumn("LogicielModule", typeof(string));
            columnLogicielModule.AllowDBNull = false;
            tableTacheProd.Columns.Add(columnLogicielModule);

            var columnNumeroVersion = new DataColumn("NumeroVersion", typeof(float));
            columnNumeroVersion.AllowDBNull = false;
            tableTacheProd.Columns.Add(columnNumeroVersion);

            var columnLogicielversion = new DataColumn("Logicielversion", typeof(string));
            columnLogicielversion.AllowDBNull = false;
            tableTacheProd.Columns.Add(columnLogicielversion);
            #endregion


            //Chargement de la liste de produits dans les tables tache, travail et tacheProd
            #region  Chargement TableTache

            foreach (var p in listTacheProd)
            {
                DataRow ligne = tableTache.NewRow();
                Guid id = Guid.NewGuid();

                //Chargement de la table mémoire tableTache
                ligne["Id"] = id;
                ligne["Libelle"] = p.Libelle;
                ligne["Annexe"] = 0;
                ligne["Activite"] = p.Activite;
                ligne["Login"] = p.Login;
                ligne["Description"] = p.Description;

                tableTache.Rows.Add(ligne);

                DataRow ligneprod = tableTacheProd.NewRow();
                //Chargement de la table mémoire tableTacheProd
                ligneprod["Id"] = id;
                ligneprod["DureePrevue"] = p.DureePrevue;
                ligneprod["DureeRestante"] = p.DureeRestante;
                ligneprod["Module"] = p.Module;
                ligneprod["LogicielModule"] = p.LogicielModule;
                ligneprod["NumeroVersion"] = p.NumeroVersion;
                ligneprod["Logicielversion"] = p.Logiciel;

                tableTacheProd.Rows.Add(ligneprod);

                //Chargement de la table mémoire Travail
                if (p.Travaux != null)
                {
                    foreach (var a in p.Travaux)
                    {
                        DataRow ligneTrav = tableTravail.NewRow();

                        ligneTrav["Id"] = id;
                        ligneTrav["DateTravail"] = a.Date;
                        ligneTrav["Heures"] = a.Heure;
                        ligneTrav["TauxProductivite"] = a.TauxProductivite;

                        tableTravail.Rows.Add(ligneTrav);
                    }

                }
            }
            #endregion
        }

        /// <summary>
        /// Chargement des tâches de production et des travaux de la base pour l'export
        /// </summary>
        /// <param name="pays"></param>
        /// <returns></returns>
        public static List<TacheProd> GetTacheExport()
        {
            var listeTacheProd = new List<TacheProd>();

            var connectString = ListeDonnees.Connexion.Chaine;
            string queryString = @"select DateTravail,Heures,TauxProductivite,Libelle,CodeActivite,login,Description,Numero,
                 DureePrevue,DureeRestanteEstimee,CodeLogicieModule, CodeModule, NumeroVersion,CodeLogicielVersion
                 from jo.Travail TR
                 inner join jo.Tache T on T.IdTache = TR.IdTache
                 inner join jo.TacheProd TP on TP.IdTache = T.IdTache
                 order by Numero";

            using (var connect = new SqlConnection(connectString))
            {
                var command = new SqlCommand(queryString, connect);
                connect.Open();

                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        GetTachesFromDataReader(listeTacheProd, reader);
                    }
                }
            }

            return listeTacheProd;
        }

        private static void GetTachesFromDataReader(List<TacheProd> lstTacheProd, SqlDataReader reader)
        {
            int numTache = (int)reader["Numero"];
            TacheProd tch = null;
            if ((lstTacheProd.Count == 0) || (lstTacheProd[lstTacheProd.Count - 1].Numero != numTache))
            {
                tch = new TacheProd();
                //Attention aux champs nullable
                tch.Libelle = (string)reader["Libelle"];
                tch.Activite = (string)reader["CodeActivite"];
                tch.Login = (string)reader["login"];
                if (reader["Description"] != DBNull.Value)
                    tch.Description = (string)reader["Description"];

                tch.Numero = (int)reader["Numero"];
                tch.DureePrevue = (float)reader["DureePrevue"];
                tch.DureeRestante = (float)reader["DureeRestanteEstimee"];
                tch.Module = (string)reader["CodeModule"];
                tch.LogicielModule = (string)reader["CodeLogicielVersion"];
                tch.NumeroVersion = (float)reader["NumeroVersion"];
                tch.Logiciel = (string)reader["CodeLogicielVersion"];

                tch.Travaux = new List<Travail>();
                lstTacheProd.Add(tch);
            }
            else
            {
                tch = lstTacheProd[lstTacheProd.Count - 1];

            }
            Travail tra = new Travail();

            tra.Date = (DateTime)reader["DateTravail"];
            tra.Heure = (float)reader["Heures"];
            tra.TauxProductivite = (float)reader["TauxProductivite"];
            tch.Travaux.Add(tra);
        }

    }
}
