﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using JobOverview.POCO;
using System.Xml.Serialization;
using System.IO;
using System.Xml.Linq;
using System.Xml;
using System.Data.SqlClient;
using System.Data;

namespace JobOverview.DAL
{
    public static class DALEchange
    {
        //Méthode qui fait le chargement des données du fichier XML contenant la liste des tâches
        public static List<TacheProd> ImporterXML(string path)
        {
            XDocument doc = XDocument.Load(path);
            List<TacheProd> listeTacheProd = new List<TacheProd>();

            //Je récupère la liste des tâches de production
            var listTache = doc.Descendants("TacheProd").ToList();
            foreach (var a in listTache)
            {
                TacheProd tache = new TacheProd();
                tache.Activite = (string)a.Attribute("Activite");
                tache.DureePrevue = (float)a.Attribute("DureePrev");
                tache.DureeRestante = (float)a.Attribute("DureeRest");
                tache.Libelle = (string)a.Attribute("Libelle");
                //tache.Description = null;
                tache.Logiciel = (string)a.Attribute("Logiciel");
                tache.LogicielModule = tache.Logiciel;
                tache.Login = (string)a.Attribute("Personne");
                tache.Module = (string)a.Attribute("Module");
                tache.NumeroVersion = (float)a.Attribute("Version");

                tache.Travaux = new List<Travail>();
                var trav = a.Descendants("Travail").ToList();

                foreach (var b in trav)
                {
                    Travail tr = new Travail();
                    tr.Date = (DateTime)b.Attribute("Date");
                    tr.Heure = (float)b.Attribute("Heures");
                    tr.TauxProductivite = (float)b.Attribute("TauxProduct");
                    tache.Travaux.Add(tr);
                }
                listeTacheProd.Add(tache);
            }

            return listeTacheProd;
        }

        public static void ExporterXML(List<TacheProd> lstTacheProd, string path)
        {
            XmlWriterSettings settings = new XmlWriterSettings();
            settings.Indent = true;
            settings.IndentChars = "\t";

            using (XmlWriter writer = XmlWriter.Create(path, settings)) //@"..\..\TachesProd_Writer.xml"
            {
                // Ecriture du prologue
                writer.WriteStartDocument();

                // Ecriture de l'élément racine
                writer.WriteStartElement("TachesProduction"); //Ajouter espace de nom
                writer.WriteAttributeString("xmlns", "xsi", null, "http://www.w3.org/2001/XMLSchema-instance");
                writer.WriteAttributeString("xmlns", "xsd", null, "http://www.w3.org/2001/XMLSchema");

                // Ecriture du contenu interne, avec une structure différente
                // de celle de la collection d'objets passée en paramètre
                foreach (TacheProd col in lstTacheProd)
                {
                    writer.WriteStartElement("TacheProd");
                    writer.WriteAttributeString("Libelle", col.Libelle);
                    writer.WriteAttributeString("Activite", col.Activite);
                    writer.WriteAttributeString("Personne", col.Login);
                    writer.WriteAttributeString("DureePrev", col.DureePrevue.ToString());
                    writer.WriteAttributeString("DureeRest", col.DureeRestante.ToString());
                    writer.WriteAttributeString("Logiciel", col.Logiciel);
                    writer.WriteAttributeString("Module", col.Module);
                    writer.WriteAttributeString("Version", col.NumeroVersion.ToString());

                    writer.WriteStartElement("Travaux");

                    foreach (Travail a in col.Travaux)
                    {
                        writer.WriteStartElement("Travail");
                        writer.WriteAttributeString("Date", a.Date.ToString("yyyy-MM-ddTHH\\:mm\\:ss"));
                        writer.WriteAttributeString("Heures", a.Heure.ToString());
                        writer.WriteAttributeString("TauxProduct", a.TauxProductivite.ToString());
                        writer.WriteEndElement();
                    }

                    writer.WriteEndElement();
                    writer.WriteEndElement();
                }

                // Ecriture de la balise fermante de l'élément racine et fin du document
                writer.WriteEndElement();
                writer.WriteEndDocument();
            }
        }
    }
}
