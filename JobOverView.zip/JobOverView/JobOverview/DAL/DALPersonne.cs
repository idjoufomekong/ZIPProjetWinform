﻿using JobOverview.POCO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JobOverview.DAL
{
    public class DALPersonne
    {
        // Récupération de la liste de personne d'un équipe (avec ou sans tache associée)
        public static BindingList<Personne> GetPersonnes()
        {
            var listPersonne = new BindingList<Personne>();

            var connectString = ListeDonnees.Connexion.Chaine; 
            string queryString = @"select Distinct P.Login, P.Prenom +' '+P.Nom NomComplet, T.IdTache, T.Libelle, 
                T.Description, TP.Numero, TP.DureeRestanteEstimee,TP.CodeLogicielVersion,TP.NumeroVersion,
                P.CodeMetier  
                from jo.Tache T
                inner join jo.TacheProd TP on TP.IdTache = T.IdTache
                right outer join jo.Personne P on T.Login = P.Login 
                where CodeEquipe = 'BIOH_DEV'
                order by 1";

            using (var connect = new SqlConnection(connectString))
            {
                var command = new SqlCommand(queryString, connect);
                connect.Open();

                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        GetpersonneFromDataReader(listPersonne, reader);
                    }
                }
            }

            return listPersonne;
        }

        private static void GetpersonneFromDataReader(BindingList<Personne> listPers, SqlDataReader reader)
        {
            string login = (string)reader["Login"];
            Personne pers = null;
            if ((listPers.Count == 0) || (listPers[listPers.Count - 1].Login != login))
            {
                pers = new Personne();
                //Attention aux champs nullable
                pers.Login = (string)reader["Login"];
                pers.NomComplet = (string)reader["NomComplet"];
                pers.CodeMetier = (string)reader["CodeMetier"];

                pers.ListeTacheProd = new List<TacheProd>();
                listPers.Add(pers);
            }
            else
            {
                pers = listPers[listPers.Count - 1];

            }
            if (!string.IsNullOrEmpty(reader["Numero"].ToString()))
            {
                TacheProd tache = new TacheProd();
                tache.Numero = (int)reader["Numero"];
                tache.Libelle = (string)reader["Libelle"];
                if (reader["Description"] != DBNull.Value)
                    tache.Description = (string)reader["Description"];
                tache.DureeRestante = (float)reader["DureeRestanteEstimee"];
                tache.NumeroVersion = (float)reader["NumeroVersion"];
                tache.Logiciel = (string)reader["CodeLogicielVersion"];
                pers.ListeTacheProd.Add(tache);
            }
        }
    }
}
