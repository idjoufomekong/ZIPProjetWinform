﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JobOverview.POCO
{
    public class Personne
    {
        public string Login { get; set; }
        public string NomComplet { get; set; }
        public string  CodeMetier { get; set; }
        public List<TacheProd> ListeTacheProd { get; set; }
    }
    public class Activite
    {
        public string CodeActivite { get; set; }
        public string Libelle { get; set; }
    }
}
