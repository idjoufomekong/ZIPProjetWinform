﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JobOverview.POCO
{
    public static class ListeDonnees
    {
        public static List<Logiciel> ListeLogiciel { get; set; }
        public static BindingList<Personne> ListePersonne { get; set; }
        public static Personne PersonneTache { get; set; }
        public static List<Module> ListeModule { get; set; }
        public static List<TacheProd> ListeTacheProd { get; set; }
        public static List<ChaineConnexion> ListeConnexion { get; set; }
        public static ChaineConnexion Connexion { get; set; }
    }

    public class ChaineConnexion
    {
        public string Nom { get; set; }
        public string Chaine { get; set; }
    }
}
