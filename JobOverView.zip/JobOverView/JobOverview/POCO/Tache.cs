﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
/// <summary>
/// Classe concernant tout ce quia trait aux tâches
/// </summary>
namespace JobOverview.POCO
{
    public class TacheProd
    {
        public int Numero { get; set; }
        public string Login { get; set; }
        public string Libelle { get; set; }
        public string Description { get; set; }
        public float DureeRestante { get; set; }
        public float NumeroVersion { get; set; }
        public string Logiciel { get; set; }
        public string Activite { get; set; }
        public float DureePrevue { get; set; }
        public string Module { get; set; }
        public string LogicielModule { get; set; }
        public List<Travail> Travaux { get; set; }
    }

    public class Travail
    {
        public DateTime Date { get; set; }
        public float Heure { get; set; }
        public float TauxProductivite { get; set; }
    }
}
