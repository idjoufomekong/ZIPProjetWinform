﻿namespace JobOverview.FORM
{
    partial class AjoutVersionForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnAjouter = new System.Windows.Forms.Button();
            this.btnAnnuler = new System.Windows.Forms.Button();
            this.lblNumVersion = new System.Windows.Forms.Label();
            this.lblMillesime = new System.Windows.Forms.Label();
            this.lblDatePrevue = new System.Windows.Forms.Label();
            this.mtbMillesime = new System.Windows.Forms.MaskedTextBox();
            this.mtbDateSortiePrevue = new System.Windows.Forms.MaskedTextBox();
            this.mtbNumVersion = new System.Windows.Forms.MaskedTextBox();
            this.lblDateOuverture = new System.Windows.Forms.Label();
            this.mtbDateOuverture = new System.Windows.Forms.MaskedTextBox();
            this.SuspendLayout();
            // 
            // btnAjouter
            // 
            this.btnAjouter.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnAjouter.Location = new System.Drawing.Point(24, 132);
            this.btnAjouter.Name = "btnAjouter";
            this.btnAjouter.Size = new System.Drawing.Size(75, 23);
            this.btnAjouter.TabIndex = 0;
            this.btnAjouter.Text = "Ajouter";
            this.btnAjouter.UseVisualStyleBackColor = true;
            // 
            // btnAnnuler
            // 
            this.btnAnnuler.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnAnnuler.Location = new System.Drawing.Point(126, 132);
            this.btnAnnuler.Name = "btnAnnuler";
            this.btnAnnuler.Size = new System.Drawing.Size(75, 23);
            this.btnAnnuler.TabIndex = 1;
            this.btnAnnuler.Text = "Annuler";
            this.btnAnnuler.UseVisualStyleBackColor = true;
            // 
            // lblNumVersion
            // 
            this.lblNumVersion.AutoSize = true;
            this.lblNumVersion.Location = new System.Drawing.Point(21, 20);
            this.lblNumVersion.Name = "lblNumVersion";
            this.lblNumVersion.Size = new System.Drawing.Size(96, 13);
            this.lblNumVersion.TabIndex = 2;
            this.lblNumVersion.Text = "Numéro de version";
            // 
            // lblMillesime
            // 
            this.lblMillesime.AutoSize = true;
            this.lblMillesime.Location = new System.Drawing.Point(68, 46);
            this.lblMillesime.Name = "lblMillesime";
            this.lblMillesime.Size = new System.Drawing.Size(49, 13);
            this.lblMillesime.TabIndex = 2;
            this.lblMillesime.Text = "Millésime";
            // 
            // lblDatePrevue
            // 
            this.lblDatePrevue.AutoSize = true;
            this.lblDatePrevue.Location = new System.Drawing.Point(8, 99);
            this.lblDatePrevue.Name = "lblDatePrevue";
            this.lblDatePrevue.Size = new System.Drawing.Size(109, 13);
            this.lblDatePrevue.TabIndex = 2;
            this.lblDatePrevue.Text = "Date de sortie prévue";
            // 
            // mtbMillesime
            // 
            this.mtbMillesime.Location = new System.Drawing.Point(126, 43);
            this.mtbMillesime.Mask = "0000";
            this.mtbMillesime.Name = "mtbMillesime";
            this.mtbMillesime.Size = new System.Drawing.Size(100, 20);
            this.mtbMillesime.TabIndex = 3;
            // 
            // mtbDateSortiePrevue
            // 
            this.mtbDateSortiePrevue.Location = new System.Drawing.Point(126, 96);
            this.mtbDateSortiePrevue.Mask = "00/00/0000";
            this.mtbDateSortiePrevue.Name = "mtbDateSortiePrevue";
            this.mtbDateSortiePrevue.Size = new System.Drawing.Size(100, 20);
            this.mtbDateSortiePrevue.TabIndex = 4;
            this.mtbDateSortiePrevue.ValidatingType = typeof(System.DateTime);
            // 
            // mtbNumVersion
            // 
            this.mtbNumVersion.Location = new System.Drawing.Point(126, 17);
            this.mtbNumVersion.Mask = "000.00";
            this.mtbNumVersion.Name = "mtbNumVersion";
            this.mtbNumVersion.Size = new System.Drawing.Size(100, 20);
            this.mtbNumVersion.TabIndex = 5;
            // 
            // lblDateOuverture
            // 
            this.lblDateOuverture.AutoSize = true;
            this.lblDateOuverture.Location = new System.Drawing.Point(31, 69);
            this.lblDateOuverture.Name = "lblDateOuverture";
            this.lblDateOuverture.Size = new System.Drawing.Size(86, 13);
            this.lblDateOuverture.TabIndex = 2;
            this.lblDateOuverture.Text = "Date d\'ouverture";
            // 
            // mtbDateOuverture
            // 
            this.mtbDateOuverture.Location = new System.Drawing.Point(126, 69);
            this.mtbDateOuverture.Mask = "00/00/0000";
            this.mtbDateOuverture.Name = "mtbDateOuverture";
            this.mtbDateOuverture.Size = new System.Drawing.Size(100, 20);
            this.mtbDateOuverture.TabIndex = 4;
            this.mtbDateOuverture.ValidatingType = typeof(System.DateTime);
            // 
            // AjoutVersionForm
            // 
            this.AcceptButton = this.btnAjouter;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnAnnuler;
            this.ClientSize = new System.Drawing.Size(238, 168);
            this.ControlBox = false;
            this.Controls.Add(this.mtbNumVersion);
            this.Controls.Add(this.mtbDateOuverture);
            this.Controls.Add(this.mtbDateSortiePrevue);
            this.Controls.Add(this.lblDateOuverture);
            this.Controls.Add(this.mtbMillesime);
            this.Controls.Add(this.lblDatePrevue);
            this.Controls.Add(this.lblMillesime);
            this.Controls.Add(this.lblNumVersion);
            this.Controls.Add(this.btnAnnuler);
            this.Controls.Add(this.btnAjouter);
            this.Name = "AjoutVersionForm";
            this.Text = "AjoutVersionForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnAjouter;
        private System.Windows.Forms.Button btnAnnuler;
        private System.Windows.Forms.Label lblNumVersion;
        private System.Windows.Forms.Label lblMillesime;
        private System.Windows.Forms.Label lblDatePrevue;
        private System.Windows.Forms.MaskedTextBox mtbMillesime;
        private System.Windows.Forms.MaskedTextBox mtbDateSortiePrevue;
        private System.Windows.Forms.MaskedTextBox mtbNumVersion;
        private System.Windows.Forms.Label lblDateOuverture;
        private System.Windows.Forms.MaskedTextBox mtbDateOuverture;
    }
}