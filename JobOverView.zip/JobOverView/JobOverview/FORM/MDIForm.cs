﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using JobOverview.POCO;
using JobOverview.DAL;
using JobOverview.FORM;
using System.ComponentModel;

namespace JobOverview
{
	public partial class MDIForm : Form
	{
		// Collection des fenêtres filles
		public Dictionary<string, Form> ChildForms { get; private set; }

        public MDIForm()
		{
			InitializeComponent();
			ChildForms = new Dictionary<string, Form>();
            ListeDonnees.ListeLogiciel = new List<Logiciel>();
            ListeDonnees.ListePersonne = new BindingList<Personne>();
            ListeDonnees.ListeConnexion = new List<ChaineConnexion>();

            Connexion();

            ListeDonnees.ListeLogiciel = DALLogiciel.GetLogiciel();
            ListeDonnees.ListePersonne = DALPersonne.GetPersonnes();

            mnuVersion.Click += (object sender, EventArgs e) => ShowChild("JobOverview.FORM.VersionForm");
            menu2TacheProd.Click += (object sender, EventArgs e) => ShowChild("JobOverview.FORM.FormTacheProd");
            menuImport.Click += MenuImport_Click;
            menuExport.Click += MenuExport_Click;
            menuConnexion.Click += MenuConnexion_Click;

            // TODO : Branchement des menus
            // menu1.Click += (object sender, EventArgs e) => ShowChild("MDIApp.Form1");
        }

        private void MenuImport_Click(object sender, EventArgs e)
        {
            OpenFileDialog fil = new OpenFileDialog();
            fil.Filter = "XML Files (*.xml)|*.xml";
            if (fil.ShowDialog() == DialogResult.OK && fil.CheckFileExists)
            {
                //Chargement du fichier xml
                ListeDonnees.ListeTacheProd = DALEchange.ImporterXML(fil.FileName);
                DALTache.AjoutMasseTacheProdBD(ListeDonnees.ListeTacheProd);
                using (FormImporter formSaisie = new FormImporter())
                {
                    DialogResult result = formSaisie.ShowDialog();
                };
            }
        }

        private void MenuExport_Click(object sender, EventArgs e)
        {
            SaveFileDialog dos = new SaveFileDialog();
            dos.Filter = "XML Files (*.xml)|*.xml";
            dos.DefaultExt = "xml";
            dos.AddExtension = true;
            if (dos.ShowDialog() == DialogResult.OK && !string.IsNullOrWhiteSpace(dos.FileName))
            {
                // Exportation de la liste sous format xml
                ListeDonnees.ListeTacheProd = DALTache.GetTacheExport();
                DALEchange.ExporterXML(ListeDonnees.ListeTacheProd, dos.FileName);
                using (FormExporter formSaisie = new FormExporter())
                {
                    DialogResult result = formSaisie.ShowDialog();
                };
            }
        }

        private void MenuConnexion_Click(object sender, EventArgs e)
        {
            Connexion();
        }
        private void Connexion()
        {
            using (var form = new ConnexionForm())
            {
                form.ShowDialog();
            }
        }

        // Affichage d'une fenêtre fille
        private void ShowChild(string name)
		{
			// Dans la collection des fenêtres filles, on recherche une fenêtre
			// dont le nom correspond à celui passé en paramètre...
			this.SuspendLayout();   // On stope le rafraîchissement du visuel
			Form form;
			if (!ChildForms.TryGetValue(name, out form))
			{
				// Si on n'en a pas trouvé, on crée une instance de cette fenêtre
				Type t = Type.GetType(name);
				form = (Form)Activator.CreateInstance(t);
				form.Name = name;

				form.MdiParent = this;
				form.FormClosed += (object sender, FormClosedEventArgs e) => RemoveChild(form);
				form.MaximizeBox = false;
				form.MinimizeBox = false;
				form.Show();

				// on ajoute la fenêtre à la collection des fenêtres filles
				// et on crée un menu associé
				AddChild(form);
				menuWindows.Visible = true;
			}

			// On maximise la taille de la fenêtre
			form.Select();
			form.WindowState = FormWindowState.Maximized;
			this.ResumeLayout(); // Rafraîchit le visuel
		}

		// Ajoute une fenêtre fille et son entrée dans le menu Fenêtres
		private void AddChild(Form f)
		{
			ChildForms.Add(f.Name, f);
			var it = menuWindows.DropDownItems.Add(f.Text);
			it.Name = f.Name;
			it.Click += (object sender, EventArgs e) => ShowChild(it.Name);
		}


		// Supprime une fenêtre fille et son entrée dans le menu Fenêtres
		private void RemoveChild(Form f)
		{
			ChildForms.Remove(f.Name);
			menuWindows.DropDownItems.RemoveByKey(f.Name);
			if (ChildForms.Count == 0) menuWindows.Visible = false;
		}

    }
}
