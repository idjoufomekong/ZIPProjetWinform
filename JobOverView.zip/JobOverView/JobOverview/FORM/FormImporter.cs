﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using JobOverview.DAL;
using JobOverview.POCO;

namespace JobOverview.FORM
{
    public partial class FormImporter : Form
    {
        public FormImporter()
        {
            InitializeComponent();
        }

        protected override void OnLoad(EventArgs e)
        {
            
                SuivreProgression();
                label1.Text = "Import réussi! Vous pouvez accéder aux données";

            base.OnLoad(e);
        }

        private void SuivreProgression()
        {
            int i;

            progressBar1.Minimum = 0;
            progressBar1.Maximum = 200;

            for (i = 0; i <= 200; i++)
            {
                progressBar1.Value = i;
            }
        }
    }
}
