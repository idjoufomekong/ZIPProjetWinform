﻿namespace JobOverview
{
	partial class MDIForm
	{
		/// <summary>
		/// Variable nécessaire au concepteur.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Nettoyage des ressources utilisées.
		/// </summary>
		/// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Code généré par le Concepteur Windows Form

		/// <summary>
		/// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
		/// le contenu de cette méthode avec l'éditeur de code.
		/// </summary>
		private void InitializeComponent()
		{
            this.menuGeneral = new System.Windows.Forms.MenuStrip();
            this.mnuVersion = new System.Windows.Forms.ToolStripMenuItem();
            this.menu2Tache = new System.Windows.Forms.ToolStripMenuItem();
            this.menu2TacheProd = new System.Windows.Forms.ToolStripMenuItem();
            this.menu2TacheAnnexe = new System.Windows.Forms.ToolStripMenuItem();
            this.menuEchange = new System.Windows.Forms.ToolStripMenuItem();
            this.menuImport = new System.Windows.Forms.ToolStripMenuItem();
            this.menuExport = new System.Windows.Forms.ToolStripMenuItem();
            this.menuConnexion = new System.Windows.Forms.ToolStripMenuItem();
            this.menuWindows = new System.Windows.Forms.ToolStripMenuItem();
            this.menuGeneral.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuGeneral
            // 
            this.menuGeneral.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuVersion,
            this.menu2Tache,
            this.menuEchange,
            this.menuConnexion,
            this.menuWindows});
            this.menuGeneral.Location = new System.Drawing.Point(0, 0);
            this.menuGeneral.Name = "menuGeneral";
            this.menuGeneral.Size = new System.Drawing.Size(610, 24);
            this.menuGeneral.TabIndex = 0;
            this.menuGeneral.Text = "menuStrip1";
            // 
            // mnuVersion
            // 
            this.mnuVersion.Name = "mnuVersion";
            this.mnuVersion.Size = new System.Drawing.Size(62, 20);
            this.mnuVersion.Text = "Versions";
            // 
            // menu2Tache
            // 
            this.menu2Tache.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menu2TacheProd,
            this.menu2TacheAnnexe});
            this.menu2Tache.Name = "menu2Tache";
            this.menu2Tache.Size = new System.Drawing.Size(55, 20);
            this.menu2Tache.Text = "Tâches";
            // 
            // menu2TacheProd
            // 
            this.menu2TacheProd.Name = "menu2TacheProd";
            this.menu2TacheProd.Size = new System.Drawing.Size(188, 22);
            this.menu2TacheProd.Text = "Tâches de production";
            // 
            // menu2TacheAnnexe
            // 
            this.menu2TacheAnnexe.Name = "menu2TacheAnnexe";
            this.menu2TacheAnnexe.Size = new System.Drawing.Size(188, 22);
            this.menu2TacheAnnexe.Text = "Tâches annexes";
            // 
            // menuEchange
            // 
            this.menuEchange.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuImport,
            this.menuExport});
            this.menuEchange.Name = "menuEchange";
            this.menuEchange.Size = new System.Drawing.Size(69, 20);
            this.menuEchange.Text = "Echanges";
            // 
            // menuImport
            // 
            this.menuImport.Name = "menuImport";
            this.menuImport.Size = new System.Drawing.Size(120, 22);
            this.menuImport.Text = "Importer";
            // 
            // menuExport
            // 
            this.menuExport.Name = "menuExport";
            this.menuExport.Size = new System.Drawing.Size(120, 22);
            this.menuExport.Text = "Exporter";
            // 
            // menuConnexion
            // 
            this.menuConnexion.Name = "menuConnexion";
            this.menuConnexion.Size = new System.Drawing.Size(76, 20);
            this.menuConnexion.Text = "Connexion";
            // 
            // menuWindows
            // 
            this.menuWindows.Name = "menuWindows";
            this.menuWindows.Size = new System.Drawing.Size(63, 20);
            this.menuWindows.Text = "Fenêtres";
            // 
            // MDIForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(610, 431);
            this.Controls.Add(this.menuGeneral);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuGeneral;
            this.Name = "MDIForm";
            this.Text = "JobOverview";
            this.menuGeneral.ResumeLayout(false);
            this.menuGeneral.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.MenuStrip menuGeneral;
		private System.Windows.Forms.ToolStripMenuItem mnuVersion;
		private System.Windows.Forms.ToolStripMenuItem menuWindows;
		private System.Windows.Forms.ToolStripMenuItem menu2Tache;
        private System.Windows.Forms.ToolStripMenuItem menu2TacheProd;
        private System.Windows.Forms.ToolStripMenuItem menu2TacheAnnexe;
        private System.Windows.Forms.ToolStripMenuItem menuEchange;
        private System.Windows.Forms.ToolStripMenuItem menuImport;
        private System.Windows.Forms.ToolStripMenuItem menuExport;
        private System.Windows.Forms.ToolStripMenuItem menuConnexion;
    }
}

