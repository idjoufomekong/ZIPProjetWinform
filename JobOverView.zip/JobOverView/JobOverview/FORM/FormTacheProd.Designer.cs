﻿namespace JobOverview.FORM
{
    partial class FormTacheProd
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.cbVersion = new System.Windows.Forms.ComboBox();
            this.cbLogiciel = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btSaveTacheProd = new System.Windows.Forms.Button();
            this.tbDescTacheProd = new System.Windows.Forms.TextBox();
            this.lblDescTacheProd = new System.Windows.Forms.Label();
            this.btDelTacheProd = new System.Windows.Forms.Button();
            this.btAddTacheProd = new System.Windows.Forms.Button();
            this.cbFiltreTaches = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.dgvTache = new System.Windows.Forms.DataGridView();
            this.label3 = new System.Windows.Forms.Label();
            this.lbPersonnes = new System.Windows.Forms.ListBox();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTache)).BeginInit();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.cbVersion);
            this.splitContainer1.Panel1.Controls.Add(this.cbLogiciel);
            this.splitContainer1.Panel1.Controls.Add(this.label2);
            this.splitContainer1.Panel1.Controls.Add(this.label1);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.btSaveTacheProd);
            this.splitContainer1.Panel2.Controls.Add(this.tbDescTacheProd);
            this.splitContainer1.Panel2.Controls.Add(this.lblDescTacheProd);
            this.splitContainer1.Panel2.Controls.Add(this.btDelTacheProd);
            this.splitContainer1.Panel2.Controls.Add(this.btAddTacheProd);
            this.splitContainer1.Panel2.Controls.Add(this.cbFiltreTaches);
            this.splitContainer1.Panel2.Controls.Add(this.label4);
            this.splitContainer1.Panel2.Controls.Add(this.dgvTache);
            this.splitContainer1.Panel2.Controls.Add(this.label3);
            this.splitContainer1.Panel2.Controls.Add(this.lbPersonnes);
            this.splitContainer1.Size = new System.Drawing.Size(495, 435);
            this.splitContainer1.SplitterDistance = 63;
            this.splitContainer1.TabIndex = 0;
            // 
            // cbVersion
            // 
            this.cbVersion.FormattingEnabled = true;
            this.cbVersion.Location = new System.Drawing.Point(365, 23);
            this.cbVersion.Name = "cbVersion";
            this.cbVersion.Size = new System.Drawing.Size(121, 21);
            this.cbVersion.TabIndex = 3;
            // 
            // cbLogiciel
            // 
            this.cbLogiciel.FormattingEnabled = true;
            this.cbLogiciel.Location = new System.Drawing.Point(88, 23);
            this.cbLogiciel.Name = "cbLogiciel";
            this.cbLogiciel.Size = new System.Drawing.Size(121, 21);
            this.cbLogiciel.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(303, 26);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(42, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Version";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(29, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(43, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Logiciel";
            // 
            // btSaveTacheProd
            // 
            this.btSaveTacheProd.Location = new System.Drawing.Point(167, 340);
            this.btSaveTacheProd.Name = "btSaveTacheProd";
            this.btSaveTacheProd.Size = new System.Drawing.Size(75, 23);
            this.btSaveTacheProd.TabIndex = 8;
            this.btSaveTacheProd.Text = "Enregistrer";
            this.btSaveTacheProd.UseVisualStyleBackColor = true;
            // 
            // tbDescTacheProd
            // 
            this.tbDescTacheProd.Location = new System.Drawing.Point(167, 313);
            this.tbDescTacheProd.Name = "tbDescTacheProd";
            this.tbDescTacheProd.Size = new System.Drawing.Size(320, 20);
            this.tbDescTacheProd.TabIndex = 7;
            // 
            // lblDescTacheProd
            // 
            this.lblDescTacheProd.AutoSize = true;
            this.lblDescTacheProd.Location = new System.Drawing.Point(167, 292);
            this.lblDescTacheProd.Name = "lblDescTacheProd";
            this.lblDescTacheProd.Size = new System.Drawing.Size(179, 13);
            this.lblDescTacheProd.TabIndex = 6;
            this.lblDescTacheProd.Text = "Description de la tâche sélectionnée";
            // 
            // btDelTacheProd
            // 
            this.btDelTacheProd.Location = new System.Drawing.Point(207, 13);
            this.btDelTacheProd.Name = "btDelTacheProd";
            this.btDelTacheProd.Size = new System.Drawing.Size(28, 23);
            this.btDelTacheProd.TabIndex = 5;
            this.btDelTacheProd.Text = "-";
            this.btDelTacheProd.UseVisualStyleBackColor = true;
            // 
            // btAddTacheProd
            // 
            this.btAddTacheProd.Location = new System.Drawing.Point(173, 12);
            this.btAddTacheProd.Name = "btAddTacheProd";
            this.btAddTacheProd.Size = new System.Drawing.Size(28, 23);
            this.btAddTacheProd.TabIndex = 5;
            this.btAddTacheProd.Text = "+";
            this.btAddTacheProd.UseVisualStyleBackColor = true;
            // 
            // cbFiltreTaches
            // 
            this.cbFiltreTaches.FormattingEnabled = true;
            this.cbFiltreTaches.Location = new System.Drawing.Point(365, 15);
            this.cbFiltreTaches.Name = "cbFiltreTaches";
            this.cbFiltreTaches.Size = new System.Drawing.Size(121, 21);
            this.cbFiltreTaches.TabIndex = 4;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(266, 23);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(93, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Tâches associées";
            // 
            // dgvTache
            // 
            this.dgvTache.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTache.Location = new System.Drawing.Point(167, 42);
            this.dgvTache.Name = "dgvTache";
            this.dgvTache.Size = new System.Drawing.Size(320, 238);
            this.dgvTache.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(32, 23);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(101, 13);
            this.label3.TabIndex = 1;
            this.label3.Text = "Liste des personnes";
            // 
            // lbPersonnes
            // 
            this.lbPersonnes.FormattingEnabled = true;
            this.lbPersonnes.Location = new System.Drawing.Point(32, 42);
            this.lbPersonnes.Name = "lbPersonnes";
            this.lbPersonnes.Size = new System.Drawing.Size(120, 238);
            this.lbPersonnes.TabIndex = 0;
            // 
            // FormTacheProd
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(495, 435);
            this.Controls.Add(this.splitContainer1);
            this.Name = "FormTacheProd";
            this.Text = "Tâches de Production";
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvTache)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.ComboBox cbVersion;
        private System.Windows.Forms.ComboBox cbLogiciel;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dgvTache;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ListBox lbPersonnes;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cbFiltreTaches;
        private System.Windows.Forms.TextBox tbDescTacheProd;
        private System.Windows.Forms.Label lblDescTacheProd;
        private System.Windows.Forms.Button btDelTacheProd;
        private System.Windows.Forms.Button btAddTacheProd;
        private System.Windows.Forms.Button btSaveTacheProd;
    }
}