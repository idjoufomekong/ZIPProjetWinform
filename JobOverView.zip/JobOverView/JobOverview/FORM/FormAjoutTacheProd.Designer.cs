﻿namespace JobOverview.FORM
{
    partial class FormAjoutTacheProd
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.OK = new System.Windows.Forms.Button();
            this.Cancel = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.cbListeActivite = new System.Windows.Forms.ComboBox();
            this.tbNomTache = new System.Windows.Forms.TextBox();
            this.tbDescTache = new System.Windows.Forms.TextBox();
            this.mtbDureePrevue = new System.Windows.Forms.MaskedTextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.cbModule = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // OK
            // 
            this.OK.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.OK.Location = new System.Drawing.Point(7, 160);
            this.OK.Name = "OK";
            this.OK.Size = new System.Drawing.Size(75, 23);
            this.OK.TabIndex = 0;
            this.OK.Text = "OK";
            this.OK.UseVisualStyleBackColor = true;
            // 
            // Cancel
            // 
            this.Cancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.Cancel.Location = new System.Drawing.Point(142, 159);
            this.Cancel.Name = "Cancel";
            this.Cancel.Size = new System.Drawing.Size(75, 23);
            this.Cancel.TabIndex = 1;
            this.Cancel.Text = "Annuler";
            this.Cancel.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(2, 42);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(114, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Choisissez une activité";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(31, 65);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(85, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Nom de la tâche";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(56, 90);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(60, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Description";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(43, 117);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(73, 13);
            this.label4.TabIndex = 5;
            this.label4.Text = "Durée Prévue";
            // 
            // cbListeActivite
            // 
            this.cbListeActivite.FormattingEnabled = true;
            this.cbListeActivite.Location = new System.Drawing.Point(128, 39);
            this.cbListeActivite.Name = "cbListeActivite";
            this.cbListeActivite.Size = new System.Drawing.Size(121, 21);
            this.cbListeActivite.TabIndex = 6;
            // 
            // tbNomTache
            // 
            this.tbNomTache.Location = new System.Drawing.Point(128, 62);
            this.tbNomTache.Name = "tbNomTache";
            this.tbNomTache.Size = new System.Drawing.Size(121, 20);
            this.tbNomTache.TabIndex = 7;
            // 
            // tbDescTache
            // 
            this.tbDescTache.Location = new System.Drawing.Point(128, 87);
            this.tbDescTache.Name = "tbDescTache";
            this.tbDescTache.Size = new System.Drawing.Size(121, 20);
            this.tbDescTache.TabIndex = 7;
            // 
            // mtbDureePrevue
            // 
            this.mtbDureePrevue.Location = new System.Drawing.Point(128, 114);
            this.mtbDureePrevue.Mask = "9999.9";
            this.mtbDureePrevue.Name = "mtbDureePrevue";
            this.mtbDureePrevue.Size = new System.Drawing.Size(121, 20);
            this.mtbDureePrevue.TabIndex = 8;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(8, 12);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(108, 13);
            this.label5.TabIndex = 2;
            this.label5.Text = "Choisissez un module";
            // 
            // cbModule
            // 
            this.cbModule.FormattingEnabled = true;
            this.cbModule.Location = new System.Drawing.Point(128, 12);
            this.cbModule.Name = "cbModule";
            this.cbModule.Size = new System.Drawing.Size(121, 21);
            this.cbModule.TabIndex = 6;
            // 
            // FormAjoutTacheProd
            // 
            this.AcceptButton = this.OK;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(253, 186);
            this.ControlBox = false;
            this.Controls.Add(this.mtbDureePrevue);
            this.Controls.Add(this.tbDescTache);
            this.Controls.Add(this.tbNomTache);
            this.Controls.Add(this.cbModule);
            this.Controls.Add(this.cbListeActivite);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Cancel);
            this.Controls.Add(this.OK);
            this.Name = "FormAjoutTacheProd";
            this.Text = "Saisie des tâches de Production";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button OK;
        private System.Windows.Forms.Button Cancel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cbListeActivite;
        private System.Windows.Forms.TextBox tbNomTache;
        private System.Windows.Forms.TextBox tbDescTache;
        private System.Windows.Forms.MaskedTextBox mtbDureePrevue;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cbModule;
    }
}