﻿using JobOverview.DAL;
using JobOverview.POCO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JobOverview.FORM
{
    public partial class FormAjoutTacheProd : Form
    {
        private List<Activite> _listActivite;
        public TacheProd TacheSaisie { get; private set; }
        public FormAjoutTacheProd()
        {
            InitializeComponent();
        }
        protected override void OnLoad(EventArgs e)
        {
            Personne pers = ListeDonnees.PersonneTache;
            string metier = pers.CodeMetier;
            _listActivite = DALTache.GetActivite(metier);

            cbListeActivite.DataSource = _listActivite;
            cbListeActivite.DisplayMember = "Libelle";
            cbListeActivite.ValueMember = "CodeActivite";

            cbModule.DataSource = ListeDonnees.ListeModule;
            cbModule.DisplayMember = "Libelle";
            cbModule.ValueMember = "CodeModule";

            base.OnLoad(e);
        }

        protected override void OnClosing(CancelEventArgs e)
        {
            if (DialogResult == DialogResult.OK)
            {
                TacheSaisie = new TacheProd();
                TacheSaisie.Libelle = tbNomTache.Text;
                if (!string.IsNullOrEmpty(tbDescTache.Text))
                    TacheSaisie.Description = tbDescTache.Text;
                TacheSaisie.Activite = cbListeActivite.SelectedValue.ToString();
                float duree;
                if (float.TryParse(mtbDureePrevue.Text, out duree))
                    TacheSaisie.DureePrevue = duree;
                TacheSaisie.Module = cbModule.SelectedValue.ToString();
            }
            base.OnClosing(e);
        }
    }
}
