﻿namespace JobOverview.FORM
{
    partial class ConnexionForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnValider = new System.Windows.Forms.Button();
            this.btnAnnuler = new System.Windows.Forms.Button();
            this.lblConnexion = new System.Windows.Forms.Label();
            this.lblConnexionActuelle = new System.Windows.Forms.Label();
            this.lblAfficheConnexion = new System.Windows.Forms.Label();
            this.dgvConnexion = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dgvConnexion)).BeginInit();
            this.SuspendLayout();
            // 
            // btnValider
            // 
            this.btnValider.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnValider.Location = new System.Drawing.Point(4, 112);
            this.btnValider.Name = "btnValider";
            this.btnValider.Size = new System.Drawing.Size(75, 21);
            this.btnValider.TabIndex = 0;
            this.btnValider.Text = "Valider";
            this.btnValider.UseVisualStyleBackColor = true;
            // 
            // btnAnnuler
            // 
            this.btnAnnuler.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnAnnuler.Location = new System.Drawing.Point(96, 112);
            this.btnAnnuler.Name = "btnAnnuler";
            this.btnAnnuler.Size = new System.Drawing.Size(75, 21);
            this.btnAnnuler.TabIndex = 0;
            this.btnAnnuler.Text = "Annuler";
            this.btnAnnuler.UseVisualStyleBackColor = true;
            // 
            // lblConnexion
            // 
            this.lblConnexion.AutoSize = true;
            this.lblConnexion.Location = new System.Drawing.Point(7, 6);
            this.lblConnexion.Name = "lblConnexion";
            this.lblConnexion.Size = new System.Drawing.Size(107, 13);
            this.lblConnexion.TabIndex = 2;
            this.lblConnexion.Text = "Chaine de connexion";
            // 
            // lblConnexionActuelle
            // 
            this.lblConnexionActuelle.AutoSize = true;
            this.lblConnexionActuelle.Location = new System.Drawing.Point(1, 136);
            this.lblConnexionActuelle.Name = "lblConnexionActuelle";
            this.lblConnexionActuelle.Size = new System.Drawing.Size(98, 13);
            this.lblConnexionActuelle.TabIndex = 4;
            this.lblConnexionActuelle.Text = "Connexion Actuelle";
            // 
            // lblAfficheConnexion
            // 
            this.lblAfficheConnexion.AutoSize = true;
            this.lblAfficheConnexion.Location = new System.Drawing.Point(1, 149);
            this.lblAfficheConnexion.Name = "lblAfficheConnexion";
            this.lblAfficheConnexion.Size = new System.Drawing.Size(35, 13);
            this.lblAfficheConnexion.TabIndex = 4;
            this.lblAfficheConnexion.Text = "label1";
            // 
            // dgvConnexion
            // 
            this.dgvConnexion.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvConnexion.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvConnexion.Location = new System.Drawing.Point(4, 22);
            this.dgvConnexion.Name = "dgvConnexion";
            this.dgvConnexion.Size = new System.Drawing.Size(314, 84);
            this.dgvConnexion.TabIndex = 5;
            // 
            // ConnexionForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(321, 173);
            this.ControlBox = false;
            this.Controls.Add(this.dgvConnexion);
            this.Controls.Add(this.lblAfficheConnexion);
            this.Controls.Add(this.lblConnexionActuelle);
            this.Controls.Add(this.lblConnexion);
            this.Controls.Add(this.btnAnnuler);
            this.Controls.Add(this.btnValider);
            this.Name = "ConnexionForm";
            this.Text = "Connexion";
            ((System.ComponentModel.ISupportInitialize)(this.dgvConnexion)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnValider;
        private System.Windows.Forms.Button btnAnnuler;
        private System.Windows.Forms.Label lblConnexion;
        private System.Windows.Forms.Label lblConnexionActuelle;
        private System.Windows.Forms.Label lblAfficheConnexion;
        private System.Windows.Forms.DataGridView dgvConnexion;
    }
}