﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JobOverview.FORM
{
    public partial class AjoutVersionForm : Form
    {
        public POCO.Version VersionSaisi { get; set; }
        public AjoutVersionForm()
        {
            InitializeComponent();
        }

        protected override void OnClosing(CancelEventArgs e)
        {
            if (DialogResult == DialogResult.OK)
            {
                VersionSaisi = new POCO.Version();
                VersionSaisi.NumeroVersion = float.Parse(mtbNumVersion.Text);
                VersionSaisi.Millesime = short.Parse(mtbMillesime.Text);
                VersionSaisi.DateOuverture = DateTime.Parse(mtbDateOuverture.Text);
                VersionSaisi.DateSortiePrevue = DateTime.Parse(mtbDateSortiePrevue.Text);
            }
        }
    }
}
