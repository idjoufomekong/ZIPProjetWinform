﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JobOverview.FORM
{
    public partial class FormExporter : Form
    {
        private int _time;
        public FormExporter()
        {
            InitializeComponent();
            _time = SuivreProgression();
            label1.Visible = false;
            if(_time >0)
            for (int j = 0; j < 5; j++)
            {
                Console.WriteLine("Sleep for 2 seconds.");
                Thread.Sleep(200);
            }
            label1.Text = "Export réussie!";
            label1.Visible = true;
        }

        //protected override void OnLoad(EventArgs e)
        //{

        //    //Task.Delay(10000);

        //    base.OnLoad(e);
        //}

        private int SuivreProgression()
        {
            int i;

            progressBar1.Minimum = 0;
            progressBar1.Maximum = 200;

            for (i = 0; i <= 200; i++)
            {
                progressBar1.Value = i;
            }
            return 1;
        }
    }
}
