﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using JobOverview.POCO;
using JobOverview.DAL;

namespace JobOverview.FORM
{
    public partial class VersionForm : Form
    {
        public VersionForm()
        {
            InitializeComponent();
            cbLogiciel.SelectionChangeCommitted += CbLogiciel_SelectionChangeCommitted;
            btnSupVersion.Click += BtnSupVersion_Click;
            btnAjoutVersion.Click += BtnAjoutVersion_Click;
        }

        private void BtnAjoutVersion_Click(object sender, EventArgs e)
        {
            using (var form = new AjoutVersionForm())
            {
                DialogResult dr = form.ShowDialog();
                if (dr == DialogResult.OK)
                {
                    (ListeDonnees.ListeLogiciel.
                        Where(l => l.CodeLogiciel == (string)cbLogiciel.SelectedValue).
                        FirstOrDefault()).ListeVersion.Add(form.VersionSaisi);
                    DALLogiciel.AjoutVersion(form.VersionSaisi,
                        (string)cbLogiciel.SelectedValue);
                }
            }
        }

        private void BtnSupVersion_Click(object sender, EventArgs e)
        {
            Logiciel log = ListeDonnees.ListeLogiciel.
                Where(a => a.CodeLogiciel == (string)cbLogiciel.SelectedValue).FirstOrDefault();
            POCO.Version ver = (POCO.Version)dgvVersion.CurrentRow.DataBoundItem;
            if (DALLogiciel.NbTacheLieVersion(ver.NumeroVersion) == 0)
            {
                DALLogiciel.SuppressionVersion(log.CodeLogiciel, ver.NumeroVersion);
                log.ListeVersion.Remove((POCO.Version)dgvVersion.CurrentRow.DataBoundItem);
            }
            else
                MessageBox.Show("Suppresion impossible, des taches de productions sont associées à cette version!");
        }

        private void CbLogiciel_SelectionChangeCommitted(object sender, EventArgs e)
        {
            Logiciel log = ListeDonnees.ListeLogiciel.
                Where(a => a.CodeLogiciel == (string)cbLogiciel.SelectedValue).FirstOrDefault();

            dgvModule.DataSource = log.ListeModule;
            dgvVersion.DataSource = log.ListeVersion;
            dgvVersion.Columns["Millesime"].Visible = false;
        }

        protected override void OnLoad(EventArgs e)
        {
            cbLogiciel.DataSource = ListeDonnees.ListeLogiciel;
            cbLogiciel.DisplayMember = "Nom";
            cbLogiciel.ValueMember = "CodeLogiciel";
            base.OnLoad(e);
        }
    }
}
