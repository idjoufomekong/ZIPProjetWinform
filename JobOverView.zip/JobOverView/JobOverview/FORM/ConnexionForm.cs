﻿using JobOverview.POCO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JobOverview.FORM
{
    public partial class ConnexionForm : Form
    {
        public ConnexionForm()
        {
            InitializeComponent();
        }

        protected override void OnLoad(EventArgs e)
        {
            btnAnnuler.Visible = true;
            if (ListeDonnees.ListePersonne.Count == 0 && ListeDonnees.ListeLogiciel.Count == 0)
            {
                btnAnnuler.Visible = false;
            }

                if ((ListeDonnees.ListeConnexion.Count != 0))
                {
                    lblAfficheConnexion.Visible = true;
                    lblConnexionActuelle.Visible = true;
                    lblAfficheConnexion.Text = ListeDonnees.Connexion.Nom;
                }
                else
                {
                    ListeDonnees.ListeConnexion = new List<ChaineConnexion>();
                    lblAfficheConnexion.Visible = false;
                    lblConnexionActuelle.Visible = false;
                    foreach (SettingsProperty currentProp in Properties.Settings.Default.Properties)
                    {
                        var p = new ChaineConnexion();
                        p.Nom = currentProp.Name.ToString();
                        if (!(string.IsNullOrWhiteSpace((string)currentProp.DefaultValue)))
                        {
                            p.Chaine = currentProp.DefaultValue.ToString();
                            ListeDonnees.ListeConnexion.Add(p);
                        }
                    }
                }

            dgvConnexion.DataSource = ListeDonnees.ListeConnexion;

            base.OnLoad(e);
        }

        protected override void OnClosing(CancelEventArgs e)
        {
            if (DialogResult == DialogResult.OK)
            {
                // Data Source=MGOLLAIN17-DE\IP08R2;Initial Catalog=JobOverview;Integrated Security=True
                var conec = (ChaineConnexion)dgvConnexion.CurrentRow.DataBoundItem;
                ListeDonnees.Connexion = conec;
            }
        }
    }
}
