﻿namespace JobOverview.FORM
{
    partial class VersionForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblLogiciel = new System.Windows.Forms.Label();
            this.cbLogiciel = new System.Windows.Forms.ComboBox();
            this.dgvVersion = new System.Windows.Forms.DataGridView();
            this.lblModule = new System.Windows.Forms.Label();
            this.btnAjoutVersion = new System.Windows.Forms.Button();
            this.btnSupVersion = new System.Windows.Forms.Button();
            this.lblVersion = new System.Windows.Forms.Label();
            this.dgvModule = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dgvVersion)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvModule)).BeginInit();
            this.SuspendLayout();
            // 
            // lblLogiciel
            // 
            this.lblLogiciel.AutoSize = true;
            this.lblLogiciel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLogiciel.Location = new System.Drawing.Point(279, 16);
            this.lblLogiciel.Name = "lblLogiciel";
            this.lblLogiciel.Size = new System.Drawing.Size(64, 17);
            this.lblLogiciel.TabIndex = 0;
            this.lblLogiciel.Text = "Logiciel";
            // 
            // cbLogiciel
            // 
            this.cbLogiciel.FormattingEnabled = true;
            this.cbLogiciel.Location = new System.Drawing.Point(280, 34);
            this.cbLogiciel.Name = "cbLogiciel";
            this.cbLogiciel.Size = new System.Drawing.Size(121, 21);
            this.cbLogiciel.TabIndex = 1;
            // 
            // dgvVersion
            // 
            this.dgvVersion.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvVersion.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvVersion.Location = new System.Drawing.Point(277, 95);
            this.dgvVersion.Name = "dgvVersion";
            this.dgvVersion.Size = new System.Drawing.Size(392, 187);
            this.dgvVersion.TabIndex = 3;
            // 
            // lblModule
            // 
            this.lblModule.AutoSize = true;
            this.lblModule.Location = new System.Drawing.Point(12, 18);
            this.lblModule.Name = "lblModule";
            this.lblModule.Size = new System.Drawing.Size(42, 13);
            this.lblModule.TabIndex = 4;
            this.lblModule.Text = "Module";
            // 
            // btnAjoutVersion
            // 
            this.btnAjoutVersion.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAjoutVersion.Location = new System.Drawing.Point(332, 68);
            this.btnAjoutVersion.Name = "btnAjoutVersion";
            this.btnAjoutVersion.Size = new System.Drawing.Size(29, 23);
            this.btnAjoutVersion.TabIndex = 5;
            this.btnAjoutVersion.Text = "+";
            this.btnAjoutVersion.UseVisualStyleBackColor = true;
            // 
            // btnSupVersion
            // 
            this.btnSupVersion.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSupVersion.Location = new System.Drawing.Point(367, 68);
            this.btnSupVersion.Name = "btnSupVersion";
            this.btnSupVersion.Size = new System.Drawing.Size(29, 23);
            this.btnSupVersion.TabIndex = 5;
            this.btnSupVersion.Text = "-";
            this.btnSupVersion.UseVisualStyleBackColor = true;
            // 
            // lblVersion
            // 
            this.lblVersion.AutoSize = true;
            this.lblVersion.Location = new System.Drawing.Point(279, 73);
            this.lblVersion.Name = "lblVersion";
            this.lblVersion.Size = new System.Drawing.Size(47, 13);
            this.lblVersion.TabIndex = 6;
            this.lblVersion.Text = "Versions";
            // 
            // dgvModule
            // 
            this.dgvModule.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvModule.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvModule.Location = new System.Drawing.Point(12, 34);
            this.dgvModule.Name = "dgvModule";
            this.dgvModule.Size = new System.Drawing.Size(259, 248);
            this.dgvModule.TabIndex = 7;
            // 
            // VersionForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(675, 294);
            this.Controls.Add(this.dgvModule);
            this.Controls.Add(this.lblVersion);
            this.Controls.Add(this.btnSupVersion);
            this.Controls.Add(this.btnAjoutVersion);
            this.Controls.Add(this.lblModule);
            this.Controls.Add(this.dgvVersion);
            this.Controls.Add(this.cbLogiciel);
            this.Controls.Add(this.lblLogiciel);
            this.Name = "VersionForm";
            this.Text = "Versions";
            ((System.ComponentModel.ISupportInitialize)(this.dgvVersion)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvModule)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblLogiciel;
        private System.Windows.Forms.ComboBox cbLogiciel;
        private System.Windows.Forms.DataGridView dgvVersion;
        private System.Windows.Forms.Label lblModule;
        private System.Windows.Forms.Button btnAjoutVersion;
        private System.Windows.Forms.Button btnSupVersion;
        private System.Windows.Forms.Label lblVersion;
        private System.Windows.Forms.DataGridView dgvModule;
    }
}