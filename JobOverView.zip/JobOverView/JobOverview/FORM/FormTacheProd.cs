﻿using JobOverview.DAL;
using JobOverview.POCO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JobOverview.FORM
{
    public partial class FormTacheProd : Form
    {
        private List<Logiciel> _listLogiciel;
        private List<float> _listVersion;
        private BindingList<Personne> _listPersonne;
        private List<TacheProd> _listTacheProd;
        private List<TacheProd> _listeTotale;
        private List<string> _filtre;
        private List<TacheProd> _listeTacheProdAjouter;
        public static Personne _personneTache;

        public FormTacheProd()
        {
            InitializeComponent();

            //Branchement aux évènements
            lbPersonnes.Click += LbPersonnes_Click;
            dgvTache.SelectionChanged += DgvTache_SelectionChanged;
            cbFiltreTaches.SelectedValueChanged += CbFiltreTaches_SelectedValueChanged;
            btAddTacheProd.Click += BtAddTacheProd_Click;
            btSaveTacheProd.Click += BtSaveTacheProd_Click;
            btDelTacheProd.Click += BtDelTacheProd_Click;

            //Instanciation de listes 
            _listeTotale = new List<TacheProd>();
            _filtre = new List<string>();
            _personneTache = new Personne();
            _listeTacheProdAjouter = new List<TacheProd>();
        }


        protected override void OnLoad(EventArgs e)
        {
            //Remplissage de la liste des logiciels
            _listLogiciel = ListeDonnees.ListeLogiciel;
            cbLogiciel.DataSource = _listLogiciel;
            cbLogiciel.DisplayMember = "Nom";
            cbLogiciel.ValueMember = "CodeLogiciel";

            //Remplissage de la liste des versions
            string codeLog = (string)cbLogiciel.SelectedValue;
            var listeVers = _listLogiciel.Where(x => x.CodeLogiciel == codeLog).Select(x => x.ListeVersion).FirstOrDefault().ToList();
            _listVersion = new List<float>();
            foreach (var a in listeVers)
            {
                _listVersion.Add(a.NumeroVersion);
            }
            cbVersion.DataSource = _listVersion;

            //Remplissage de la liste des personnes
            _listPersonne = ListeDonnees.ListePersonne;
            lbPersonnes.DataSource = _listPersonne;
            lbPersonnes.DisplayMember = "NomComplet";
            lbPersonnes.ValueMember = "Login";

            //paramétrage des filtres
            _filtre.Add("Tout");
            _filtre.Add("Terminées");
            _filtre.Add("Non terminées");
            cbFiltreTaches.DataSource = _filtre;

            //Paramétrage de la zone de description
            lblDescTacheProd.Visible = false;
            tbDescTacheProd.Visible = false;

            base.OnLoad(e);
        }
        /// <summary>
        /// L'objectif de cette méthode est de permettre à l'utilisateur d'annuler les opérations d'insertion des tâches
        /// Il ne peut pas supprimer les tâches existantes en base mais annuler la création de celles
        /// qu'il vient de rentrer
        /// </summary>
        private void BtDelTacheProd_Click(object sender, EventArgs e)
        {
            TacheProd tacheToDelete = new TacheProd();
            //Je récupère la personne concernée
            string login = lbPersonnes.SelectedValue.ToString();
            var pers = _listPersonne.Where(x => x.Login == login);

            //if(dgvTache.CurrentRow.DataBoundItem != null)
            if (dgvTache.Rows.Count != 0 && dgvTache.Rows != null)
            {

                //Je récupère la tâche sélectionnée
                TacheProd tache = (TacheProd)dgvTache.CurrentRow.DataBoundItem;
                tacheToDelete.Login = lbPersonnes.SelectedValue.ToString();
                tacheToDelete.Libelle = tache.Libelle;
                tacheToDelete.NumeroVersion = (float)cbVersion.SelectedValue;

                //je vérifie si la tâche  existe dans ma liste de tâches à ajoutées
                bool suppression = false;
                foreach (var p in _listeTacheProdAjouter)
                {
                    if ((_listeTacheProdAjouter.Count != 0) && (p.Login == tache.Login) && (p.Libelle == tache.Libelle)
                        && (p.NumeroVersion == tache.NumeroVersion))
                    {
                        suppression = true;
                    }
                    else
                    {
                        DialogResult msg = MessageBox.Show("Tâche déjà enregistrée, impossible de la supprimer!",
                                    "Suppression impossible", MessageBoxButtons.OK);
                    }
                }
                if (suppression)
                {
                    _listeTacheProdAjouter.Remove(tache);
                    _listeTotale.Remove(tache);
                    pers.FirstOrDefault().ListeTacheProd.Remove(tache);
                    GetTachePersonne();
                    dgvTache.DataSource = _listeTotale;
                    #region paramètre de la datagridview
                    dgvTache.Columns["Description"].Visible = false;
                    dgvTache.Columns["NumeroVersion"].Visible = false;
                    dgvTache.Columns["Logiciel"].Visible = false;
                    dgvTache.Columns["Activite"].Visible = false;
                    dgvTache.Columns["Module"].Visible = false;
                    dgvTache.Columns["LogicielModule"].Visible = false;
                    #endregion
                }
            }
        }
        /// <summary>
        /// Bouton permettant d'enregistrer en base de données la liste des tâches ajoutée
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtSaveTacheProd_Click(object sender, EventArgs e)
        {
            if(_listeTacheProdAjouter.Count != 0)
            {
               //il serait intéressant de gérer les erreurs SQL en cas de problème pour l'insertion

                DALTache.AjoutMasseTacheProdBD(_listeTacheProdAjouter);
                DialogResult msg = MessageBox.Show("Enregistrement effectué avec succès!",
                            "Enregistrement", MessageBoxButtons.OK);
            }
            else
            {
                DialogResult msg = MessageBox.Show("Aucun enregistrement à effectuer!",
                            "Enregistrement", MessageBoxButtons.OK);
            }
        }

        private void BtAddTacheProd_Click(object sender, EventArgs e)
        {
            string login = lbPersonnes.SelectedValue.ToString();
            var pers = _listPersonne.Where(x => x.Login == login);
            string metier = pers.Select(x => x.CodeMetier).FirstOrDefault().ToString();
            ListeDonnees.PersonneTache = SavePersonToAddTache(metier);

            float numVersion = (float)cbVersion.SelectedValue;
            string log = cbLogiciel.SelectedValue.ToString();
            string module = pers.Select(x => x.CodeMetier).FirstOrDefault().ToString();

            //Chargement des modules du logiciel sélectionné
            var p = ListeDonnees.ListeLogiciel.Where(x => x.CodeLogiciel == log).Select(x => x.ListeModule).
                FirstOrDefault().ToList();
            ListeDonnees.ListeModule = new List<Module>();
            ListeDonnees.ListeModule.AddRange(p);

            using (FormAjoutTacheProd formSaisie = new FormAjoutTacheProd())
            {
                DialogResult result = formSaisie.ShowDialog();
                if (result == DialogResult.OK)
                {
                        TacheProd tache = formSaisie.TacheSaisie;
                        tache.Login = login;
                        tache.DureeRestante = tache.DureePrevue;
                        tache.LogicielModule = log;
                        tache.Logiciel = log;
                        tache.NumeroVersion = numVersion;

                        //Ajout de masse
                        _listeTacheProdAjouter.Add(tache);
                        //_listeTotale.Add(tache);
                        pers.FirstOrDefault().ListeTacheProd.Add(tache);
                        GetTachePersonne();
                        dgvTache.DataSource = _listeTotale;
                    #region paramètre de la datagridview
                    dgvTache.Columns["Description"].Visible = false;
                    dgvTache.Columns["NumeroVersion"].Visible = false;
                    dgvTache.Columns["Logiciel"].Visible = false;
                    dgvTache.Columns["Activite"].Visible = false;
                    dgvTache.Columns["Module"].Visible = false;
                    dgvTache.Columns["LogicielModule"].Visible = false;
                    #endregion
                }
            };
        }

        //Je crée une personne pour envoyer le métier de la personne sélectionnée à ma forme modale
        private Personne SavePersonToAddTache(string metier)
        {
            Personne pers = new Personne();
            pers.CodeMetier = metier;

            return pers;
        }

        private void DgvTache_SelectionChanged(object sender, EventArgs e)
        {
            if (_listeTotale.Count == 0)
            {
                lblDescTacheProd.Visible = false;
                tbDescTacheProd.Visible = false;
            }
            else
            {
                var tache = (TacheProd)dgvTache.CurrentRow.DataBoundItem;
                tbDescTacheProd.Text = tache.Description;

                //Paramétrage de la zone de description
                lblDescTacheProd.Visible = true;
                tbDescTacheProd.Visible = true;
            }
        }


        private void CbFiltreTaches_SelectedValueChanged(object sender, EventArgs e)
        {
            if (_listeTotale.Count != 0)
            {
                //Filtre sur les tâches
                string filtre = cbFiltreTaches.SelectedValue.ToString();
                switch (filtre)
                {
                    case "Non terminées":
                        _listTacheProd = _listeTotale.Where(x => x.DureeRestante > 0).ToList();
                        break;
                    case "Terminées":
                        _listTacheProd = _listeTotale.Where(x => x.DureeRestante == 0).ToList();
                        break;
                    default:
                        _listTacheProd = _listeTotale;
                        break;
                }

                dgvTache.DataSource = new BindingList<TacheProd>(_listTacheProd);
                //Paramétrage de ma Datagridview de tâches
                dgvTache.Columns["Description"].Visible = false;
                dgvTache.Columns["NumeroVersion"].Visible = false;
                dgvTache.Columns["Logiciel"].Visible = false;
                dgvTache.Columns["Activite"].Visible = false;
                dgvTache.Columns["Module"].Visible = false;
                dgvTache.Columns["LogicielModule"].Visible = false;
            }
        }
        private void GetTachePersonne()
        {

            var liste = _listPersonne.Where(x => x.Login == lbPersonnes.SelectedValue.ToString()).
                Select(x => x.ListeTacheProd).FirstOrDefault();
            _listeTotale = liste.Where(x => x.NumeroVersion == (float)(cbVersion.SelectedValue)
                  && x.Logiciel == cbLogiciel.SelectedValue.ToString()).OrderBy(x => x.Numero).ToList();
        }
        private void LbPersonnes_Click(object sender, EventArgs e)
        {
            GetTachePersonne();
            //Filtre sur les tâches
            string filtre = cbFiltreTaches.SelectedValue.ToString();
            switch (filtre)
            {
                case "Non terminées":
                    _listTacheProd = _listeTotale.Where(x => x.DureeRestante > 0).ToList();
                    break;
                case "Terminées":
                    _listTacheProd = _listeTotale.Where(x => x.DureeRestante == 0).ToList();
                    break;
                default:
                    _listTacheProd = _listeTotale;
                    break;
            }

            dgvTache.DataSource = new BindingList<TacheProd>(_listTacheProd);
            //Paramétrage de ma Datagridview de tâches
            dgvTache.Columns["Description"].Visible = false;
            dgvTache.Columns["NumeroVersion"].Visible = false;
            dgvTache.Columns["Logiciel"].Visible = false;
            dgvTache.Columns["Login"].Visible = false;
        }

    }
}
