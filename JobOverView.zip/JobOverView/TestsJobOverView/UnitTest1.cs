﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using JobOverview.DAL;
using JobOverview.POCO;
using System.Collections.Generic;
using System.Linq;

namespace TestsJobOverView
{
    [TestClass]
    public class UnitTest1
    {
        /// <summary>
        /// On veut s'assurer qu'on a bien récupéré toutes les lignes du fichier XML ce qui doit
        /// donner 15 taches de production crées
        /// </summary>
        [TestMethod]
        public void TestNombreTachesProdXML()
        {
            string path = @"..\..\TachesProd.xml";
            List<TacheProd> listTacheProd;
            listTacheProd = DALEchange.ImporterXML(path);
            Assert.AreEqual(15, listTacheProd.Count);
        }

        /// <summary>
        /// On veut s'assurer qu'on a bien tous les travaux de la tache de production 
        /// Libelle="AT Marquage" Activite="ANT" Personne="RBEAUMONT" du fichier
        /// il doit y avoir 18 travaux
        /// </summary>
        [TestMethod]
        public void TestNombreTravauxTacheATMarquageXML()
        {
            string path = @"..\..\TachesProd.xml";
            List<TacheProd> listTacheProd;
            listTacheProd = DALEchange.ImporterXML(path);
            TacheProd p = listTacheProd.Where(t => t.Activite == "ANT").Where(x => x.Login == "RBEAUMONT").
                Where(x => x.Libelle == "AT Marquage").FirstOrDefault();

             Assert.AreEqual(18,p.Travaux.Count());
        }
    }
}
